still working on the sphinx token filter plugin
